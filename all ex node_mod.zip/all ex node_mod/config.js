import {CONTACT_US_NO, PUSH_TOKEN} from 'react-native-dotenv'

export default{
    CONTACT_US_NO, PUSH_TOKEN
}
export function percHeight(size){
    return String(100*(size/(667)))+"%"
}

export function percWidth(size){
    return String(100*(size/(667)))+"%"   //return String(100*(size/(375)))+"%"
}